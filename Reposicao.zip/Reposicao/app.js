const express =require('express');
const app = express();
const PORT = 8081

app.post("/usuario", (req, res) => {
    try {
        const { dados } = req.body
        console.log(dados.nome, dados.email, dados.senha);
        res.status(201).json({erro: "Ola Sr.(a)" ${dados.nome} "Seu e-mail é" ${dados.email} "Sua senha é" {dados.senha}})




    } catch (error) {
        console.error('Os dados fornecidos estão invalidos', err.message)
        res.status(500).json({erro: "Erro ao acessar os dados do usuário"})
        
    };
});

app.listen(PORT, () => {
    console.log('Servidor rodando em http:localhost:${PORT}')

})